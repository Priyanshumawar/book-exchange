
import './App.css';
import Header from "./components/header"
import "./components/style.css"
import Footer from "./components/footer"


function App() {
  return (
    <>
      <Header/> 
      <Footer/>
      
    </>
       
  );
}

export default App;
